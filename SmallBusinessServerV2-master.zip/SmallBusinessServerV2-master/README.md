# Welcome to the SMB Blueprint ARM repository
The SMB Blueprint solution accelerator is a fast go to market solution to onboard Azure and Office 365.

The Microsoft Cloud platform consists of a vast set of technologies that allow businesses to get productive very rapidly.
While the provisioning of IT resources has become a fast process, their design is still the resposibility of the business owners.
For small businesses that just want to get to work without spending budget and effort into their IT platform,
this turnkey solution has been build. This solution allows either the business owner or their hosting partners
to quickly rollout an IT environment that adheres to Microsoft's best-practices and standards.

[Click here for the documentation site](https://inovativ.github.io/SMBblueprint-Docs/)
